<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2 class="center">Lista de Usuários</h2>

		<?php echo $__env->make('admin._caminho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		<div class="row">
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>E-mail</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($usuario->id); ?></td>
						<td><?php echo e($usuario->name); ?></td>
						<td><?php echo e($usuario->email); ?></td>
						<td>

							<a title="Papel" class="btn blue" href="<?php echo e(route('usuarios.papel',$usuario->id)); ?>"><i class="material-icons">lock_outline</i></a>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</div>

	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>