<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <h2>Lista de Chamados</h2>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create',App\Chamado::class)): ?>
      <p>Criar Chamado</p>
      <?php endif; ?>

      <?php $__empty_1 = true; $__currentLoopData = $chamados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <p><?php echo e($value->titulo); ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view',$value)): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$value)): ?>
              <a href="/home/<?php echo e($value->id); ?>">Editar</a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete',$value)): ?>
              <a href="/home/<?php echo e($value->id); ?>">Deletar</a>
            <?php endif; ?>

        <?php endif; ?>
        </p>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Não existem chamados!</p>
      <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>