<div class="slider ">
  <ul class="slides">
    <?php $__currentLoopData = $lista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <img src="<?php echo e($value->imagem); ?>"> <!-- random image -->
        <div class="caption center-align">
          <?php if(isset($value->titulo)): ?>
            <h3><?php echo e($value->titulo); ?></h3>
          <?php endif; ?>
          <?php if(isset($value->descricao)): ?>
            <h5 class="light grey-text text-lighten-3"><?php echo e($value->descricao); ?></h5>
          <?php endif; ?>

        </div>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
