<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2 class="center">Lista de Papéis</h2>

		<?php echo $__env->make('admin._caminho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="row">
			<table>
				<thead>
					<tr>
						<th>Id</th>
						<th>Nome</th>
						<th>Descrição</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($registro->id); ?></td>
						<td><?php echo e($registro->nome); ?></td>
						<td><?php echo e($registro->descricao); ?></td>

						<td>


							<form action="<?php echo e(route('papeis.destroy',$registro->id)); ?>" method="post">
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('papel-edit')): ?>
								<a title="Editar" class="btn orange" href="<?php echo e(route('papeis.edit',$registro->id)); ?>"><i class="material-icons">mode_edit</i></a>
								<a title="Permissões" class="btn blue" href="<?php echo e(route('papeis.permissao',$registro->id)); ?>"><i class="material-icons">lock_outline</i></a>
								<?php endif; ?>
								<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('papel-delete')): ?>
									<?php echo e(method_field('DELETE')); ?>

									<?php echo e(csrf_field()); ?>

									<button title="Deletar" class="btn red"><i class="material-icons">delete</i></button>
								<?php endif; ?>
							</form>








						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</div>
		<div class="row">
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('papel-create')): ?>
			<a class="btn blue" href="<?php echo e(route('papeis.create')); ?>">Adicionar</a>
			<?php endif; ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>