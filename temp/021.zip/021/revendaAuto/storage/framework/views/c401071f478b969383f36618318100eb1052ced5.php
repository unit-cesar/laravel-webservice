<?php $__env->startSection('content'); ?>
<div class="container">
	<h2 class="center">Editar Papel</h2>
	<?php echo $__env->make('admin._caminho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row">
		<form action="<?php echo e(route('papeis.update',$registro->id)); ?>" method="post">

		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<?php echo $__env->make('admin.papel._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<button class="btn blue">Atualizar</button>

			
		</form>
			
	</div>
	
</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>