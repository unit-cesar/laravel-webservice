<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view',$chamado)): ?>
      <h2>Detalhe de Chamado</h2>

      Título: <?php echo e($chamado->titulo); ?>

    <?php else: ?>
      <h3>Você não tem permissão para acessar este registro!</h3>
    <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>