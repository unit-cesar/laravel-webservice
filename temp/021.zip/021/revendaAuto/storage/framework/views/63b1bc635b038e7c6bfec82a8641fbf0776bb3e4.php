<?php $__env->startSection('content'); ?>
	<div class="container">
		<h2 class="center">Lista de Permissões para <?php echo e($papel->nome); ?></h2>

		<?php echo $__env->make('admin._caminho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<div class="row">
			<form action="<?php echo e(route('papeis.permissao.store',$papel->id)); ?>" method="post">
			<?php echo e(csrf_field()); ?>

			<div class="input-field">
				<select name="permissao_id">
					<?php $__currentLoopData = $permissao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($valor->id); ?>"><?php echo e($valor->nome); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
				<button class="btn blue">Adicionar</button>
			</form>


		</div>

		<div class="row">
			<table>
				<thead>
					<tr>

						<th>Permissão</th>
						<th>Descrição</th>
						<th>Ação</th>
					</tr>
				</thead>
				<tbody>
				<?php $__currentLoopData = $papel->permissoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($permissao->nome); ?></td>
						<td><?php echo e($permissao->descricao); ?></td>

						<td>

							<form action="<?php echo e(route('papeis.permissao.destroy',[$papel->id,$permissao->id])); ?>" method="post">
									<?php echo e(method_field('DELETE')); ?>

									<?php echo e(csrf_field()); ?>

									<button title="Deletar" class="btn red"><i class="material-icons">delete</i></button>
							</form>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</div>

	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>