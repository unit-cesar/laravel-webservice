<div class="row">
	<nav>
		<div class="nav-wrapper <?php echo e(config('app.corSite')); ?>">
		  <div class="col s12">
		  	<?php if(isset($caminhos)): ?>
			  	<?php $__currentLoopData = $caminhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caminho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<?php if($caminho['url']): ?>
				    <a href="<?php echo e($caminho['url']); ?>" class="breadcrumb"><?php echo e($caminho['titulo']); ?></a>
				    <?php else: ?>
				    	<span class="breadcrumb"><?php echo e($caminho['titulo']); ?></span>
				    <?php endif; ?>

			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    <?php else: ?>
		     <span class="breadcrumb">Admin</span>
		    <?php endif; ?>
		  </div>
		</div>
	</nav>
</div>
